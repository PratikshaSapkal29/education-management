import React from 'react';
import Navbar from './Navbar';
import '../App.css';


const StudentDashboard = () => {
  return (
    <div>
      <Navbar />
      <div className="dashboard-container">
        <h2>Student Dashboard</h2>
        <div className="cards">
          <div className="card">Attendance: 85%</div>
          <div className="card">Notices</div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
