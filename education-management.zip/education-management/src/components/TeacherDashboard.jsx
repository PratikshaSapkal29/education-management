import React from 'react';
import Navbar from './Navbar';
import '../App.css';


const TeacherDashboard = () => {
  return (
    <div>
      <Navbar />
      <div className="dashboard-container">
        <h2>Teacher Dashboard</h2>
        <div className="cards">
          <div className="card">Classes Assigned: 3</div>
          <div className="card">Manage Attendance</div>
          <div className="card">Publish Notices</div>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
