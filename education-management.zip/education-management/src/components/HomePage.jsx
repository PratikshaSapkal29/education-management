import React from 'react';
import '../App.css';

const HomePage = () => {
  return (
    <div className="home-page">
      <div>
        <h1>Welcome to Education Management System</h1>
        <p>Empowering Schools, Teachers, and Students for a Better Future</p>
        <a href="/login" className="btn">Get Started</a>
      </div>
    </div>
  );
};

export default HomePage;
