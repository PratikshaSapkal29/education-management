import React from 'react';
import '../App.css';

const Navbar = () => {
  return (
    <div className="navbar">
      <h2>School Management</h2>
      <div>
        <a href="/">Home</a>
        <a href="/login">Login</a>
        <a href="/admin">Admin</a>
        <a href="/teacher">Teacher</a>
        <a href="/student">Student</a>
      </div>
    </div>
  );
};

export default Navbar;
