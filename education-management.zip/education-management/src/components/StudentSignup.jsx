import React from 'react';
import Navbar from './Navbar';
import '../App.css';


const StudentSignup = () => {
  return (
    <div>
      <Navbar />
      <h2>Student Signup</h2>
      <form>
        <input type="text" placeholder="Name" />
        <input type="email" placeholder="Email" />
        <button type="submit">Apply</button>
      </form>
    </div>
  );
};

export default StudentSignup;
