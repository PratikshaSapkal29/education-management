import React from 'react';
import '../App.css';

const AdminDashboard = () => {
  return (
    <div className="dashboard-container">
      <div className="dashboard-sidebar">
        <h3>Admin Menu</h3>
        <ul>
          <li><a href="#">Dashboard</a></li>
          <li><a href="#">Manage Teachers</a></li>
          <li><a href="#">Manage Students</a></li>
          <li><a href="#">Announcements</a></li>
          <li><a href="#">Logout</a></li>
        </ul>
      </div>
      <div className="dashboard-main">
        <h2>Welcome, Admin</h2>
        <div className="card">
          <h2>Total Teachers</h2>
          <p>10</p>
        </div>
        <div className="card">
          <h2>Total Students</h2>
          <p>50</p>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
